"""
Phase 2 harness: runs a query workload concurrently with the ETL injector
and logs per-query latency into query_sample, tagged to an experiment_run.

Usage:
    python -m src.harness --workload temporal --etl-rate medium \
        --seconds 30 --label static

Workloads: product | customer | temporal
ETL rates: zero | low | medium | high (see config.ETL_RATES)
"""
import argparse
import random
import threading
import time

import psycopg2

from src.config import DB, ETL_RATES, DEFAULT_RUN_SECONDS
from src.etl_injector import EtlInjector
from src.query_pools import product, customer, temporal
from src.query_pools.common import get_key_ranges

POOLS = {
    "product": product.QUERIES,
    "customer": customer.QUERIES,
    "temporal": temporal.QUERIES,
}


def start_run(conn, label, workload, etl_rate):
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO experiment_run (label, workload, etl_rate) "
        "VALUES (%s, %s, %s) RETURNING run_id;",
        (label, workload, etl_rate),
    )
    run_id = cur.fetchone()[0]
    conn.commit()
    cur.close()
    return run_id


def end_run(conn, run_id):
    cur = conn.cursor()
    cur.execute("UPDATE experiment_run SET ended_at = now() WHERE run_id = %s;", (run_id,))
    conn.commit()
    cur.close()


def log_sample(conn, run_id, template_name, latency_ms, rows_returned):
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO query_sample (run_id, query_template, latency_ms, rows_returned) "
        "VALUES (%s, %s, %s, %s);",
        (run_id, template_name, latency_ms, rows_returned),
    )
    conn.commit()
    cur.close()


def run_query_workload(run_id, workload, duration_s, stop_event):
    conn = psycopg2.connect(**DB)
    conn.autocommit = True
    ranges = get_key_ranges(conn)
    rng = random.Random()
    queries = POOLS[workload]

    end_time = time.time() + duration_s
    n_run = 0
    while time.time() < end_time and not stop_event.is_set():
        name, sql, param_fn = rng.choice(queries)
        params = param_fn(ranges, rng)

        cur = conn.cursor()
        t0 = time.perf_counter()
        try:
            cur.execute(sql, params)
            rows = cur.fetchall()
            latency_ms = (time.perf_counter() - t0) * 1000
            log_sample(conn, run_id, name, latency_ms, len(rows))
            n_run += 1
        except Exception as e:
            print(f"[harness] query error ({name}): {e}")
        finally:
            cur.close()

    conn.close()
    return n_run


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workload", choices=list(POOLS.keys()), required=True)
    parser.add_argument("--etl-rate", choices=list(ETL_RATES.keys()), default="zero")
    parser.add_argument("--seconds", type=int, default=DEFAULT_RUN_SECONDS)
    parser.add_argument("--label", default="static")
    args = parser.parse_args()

    conn = psycopg2.connect(**DB)
    run_id = start_run(conn, args.label, args.workload, args.etl_rate)
    print(f"Starting run_id={run_id} label={args.label} workload={args.workload} "
          f"etl_rate={args.etl_rate} duration={args.seconds}s")

    stop_event = threading.Event()
    injector = EtlInjector(ETL_RATES[args.etl_rate], args.seconds, stop_event)
    injector.start()

    n_run = run_query_workload(run_id, args.workload, args.seconds, stop_event)

    injector.stop()
    injector.join()
    end_run(conn, run_id)

    print(f"Run finished: {n_run} queries logged, "
          f"{injector.rows_inserted} ETL rows inserted ({injector.errors} ETL errors).")
    conn.close()


if __name__ == "__main__":
    main()
